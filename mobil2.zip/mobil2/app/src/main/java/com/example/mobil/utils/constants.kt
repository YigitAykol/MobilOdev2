package com.example.mobil.utils

import com.example.mobil.R

val DEFAULT_ICONS = listOf(

    R.drawable.ic_face,
    R.drawable.ic_battery,
    R.drawable.ic_headset,
    R.drawable.ic_bookmark,
    R.drawable.ic_cocktail,
    R.drawable.ic_fitness,
    R.drawable.ic_gamepad,
    R.drawable.ic_screen,
    R.drawable.ic_swimming,
    R.drawable.ic_tsunami,
    R.drawable.ic_launcher_background,
    R.drawable.ic_skateboarding,
    R.drawable.ic_circle,


)