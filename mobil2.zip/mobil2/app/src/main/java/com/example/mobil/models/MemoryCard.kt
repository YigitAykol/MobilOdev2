package com.example.mobil.models

class MemoryCard {

    
}